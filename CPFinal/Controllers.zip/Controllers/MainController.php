<?php

namespace App\Http\Controllers;

use App\Models\CommentC;
use App\Models\contacts;
use App\Models\issued_certificates;
use App\Models\Referencess;
use App\Models\Udo;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Barryvdh\DomPDF\Facade as PDF;

class MainController extends Controller
{
    public function register_new(Request $request){

        $valid = $request->validate([
            'name' => 'required|min:1|max:100',
            'surname' => 'required|min:1|max:100',
            'lastname' => 'required|min:1|max:100',
            'birthday' => 'required|min:1|max:100',
            'inn' => 'required|min:1|max:100',
            'place' => 'required|min:1|max:100',
            'wife' => 'required|min:1|max:100',
            'order' => 'required|min:1|max:100',
            'education' => 'required|min:1|max:100',
            'nation' => 'required|min:1|max:100',
            'special' => 'required|min:1|max:100',
            'military' => 'required|min:1|max:100',
            'sports_category' => 'required|min:1|max:100',
            'postponement' => 'required|min:1|max:100',
            'conviction' => 'required|min:1|max:100',
            'email' => 'required|min:1|max:100',
        ]);

        $review = new contacts();
        $review ->name = $request -> input('name');
        $review ->surname = $request -> input('surname');
        $review ->lastname = $request -> input('lastname');
        $review ->birthday = $request -> input('birthday');
        $review ->inn = $request -> input('inn');
        $review ->place = $request -> input('place');
        $review ->wife = $request -> input('wife');
        $review ->order = $request -> input('order');
        $review ->nation = $request -> input('nation');
        $review ->education = $request -> input('education');
        $review ->special = $request -> input('special');
        $review ->military = $request -> input('military');
        $review ->sports_category = $request -> input('sports_category');
        $review ->postponement = $request -> input('postponement');
        $review ->conviction = $request -> input('conviction');
        $review ->email = $request -> input('email');



        if($review->save()){
            $address=$_POST['place'];
            $g_row = DB::table('udos')->get();
            foreach($g_row as $row){
                if($row->id==1){
                    $quan1=($row->quantity);
                }
                elseif ($row->id==2){
                    $quan2=($row->quantity);
                }
                elseif ($row->id==3){
                    $quan3=($row->quantity);
                }
                elseif($row->id==4){
                    $quan4=($row->quantity);
                }
                elseif($row->id==5){
                    $quan5=($row->quantity);
                }
                elseif($row->id==6){
                    $quan6=($row->quantity);
                }
            }


            if (strstr($address,"Алматы")){
                $update_quan =DB::table('udos')->where('id',1)
                    ->update(array('quantity' => ($quan1+1)));
            }
            if (strstr($address,"Шымкент")){
                echo "dfdsf";
                $update_quan = DB::table('udos')->where('id',2)
                    ->update(array('quantity' => ($quan2+1)));
            }
            if (strstr($address,"Нур-Султан")){
                $update_quan =DB::table('udos')->where('id',3)
                    ->update(array('quantity' => ($quan3+1)));
            }
            if (strstr($address,"Актобе")){
                $update_quan =DB::table('udos')->where('id',4)
                    ->update(array('quantity' => ($quan4+1)));
            }
            if (strstr($address,"Семей")){
                $update_quan =DB::table('udos')->where('id',5)
                    ->update(array('quantity' => ($quan5+1)));
            }
            if (strstr($address,"Караганда")){
                $update_quan =DB::table('udos')->where('id',6)
                    ->update(array('quantity' => ($quan6+1)));
            }

        }
        $ss=111;
        return redirect()->route('register',['parameter'=>$ss]);
    }

    public function students_list(){
        $list = DB::table('contacts')->get();
        return view('students_list', ['lists' => $list]);
    }

    public  function  filter(){
        $filter = DB::table('contacts')->get();
        return view('filter',['filter'=> $filter]);
    }

    public  function  search(){
        $filter = DB::table('contacts')->get();
        return view('search',['filter'=> $filter]);
    }

    public function edit_con(){

        $edit_con = DB::table('contacts')->get();
        return view('edit_con',['edit_con'=> $edit_con]);
    }

    public function edit_db2(){
        $edit_db2 = DB::table('contacts')->get();
        return view('edit_db2',['edit_db2'=>$edit_db2]);
    }

    public function edit_save(){
        $edit_save = DB::table('contacts')->where('id',$_POST['id'])
            ->update(array('name' => $_POST['name'],
                'surname'=>$_POST['surname'],
                'lastname' => $_POST['lastname'],
                'birthday' => $_POST['birthday'],
                'inn' => $_POST['inn'],
                'place' => $_POST['place'],
                'wife' => $_POST['wife'],
                'order' => $_POST['order'],
                'education' => $_POST['education'],
                'nation' => $_POST['nation'],
                'special' => $_POST['special'],
                'military' => $_POST['military'],
                'sports_category' => $_POST['sports_category'],
                'postponement' => $_POST['postponement'],
                'conviction' => $_POST['conviction'],
                'email' => $_POST['email']));
        return view('index',['edit_save'=>$edit_save]);
    }

    public function adminproverka(){
        if ($_POST['adminName']=="admin" and $_POST['passAdmin'] == 'admin'){
            $admin = DB::table('contacts')->get();

            return view('adminpage',['admin'=>$admin]);

        }
        else return view('index');
    }

    public function delete_admin_stu(){
        $del=DB::table('contacts')->where('id', $_POST['idd'])->delete();
        return view('adminpage',['delete'=>$del]) ;
    }

    public function delete_admin_spr(){
        $del=DB::table('referencesses')->where('id', $_POST['idd'])->delete();
        return view('admin_spr',['delete'=>$del]) ;
    }

    public function add_admin_spr(Request $req){
        $valid2 = $req->validate([
            'name' => 'required|min:1|max:100',
            'description' => 'required|min:1|max:100',
            'issued' => 'required|min:1|max:100',
        ]);

        $review1 = new Referencess();
        $review1-> name = $req -> input('name');
        $review1 -> description = $req -> input('description');
        $review1 -> issued = $req -> input('issued');

        $review1->save();
        return redirect()->route('admin_spravka');
    }

    public function comment(Request $req1){
        $valid92 = $req1->validate([
            'email' => 'required|min:1|max:100',
            'review' => 'required|min:1|max:100',
        ]);

        $review11 = new CommentC();
        $review11-> email = $req1 -> input('email');
        $review11 -> review = $req1 -> input('review');


        $review11->save();
        return redirect()->route('contacts');
    }

    public function  send_mess(){
        $email=$_POST['email'];
        $com=$_POST['mess'];

        $mail= new \PHPMailer\PHPMailer\PHPMailer(true);
        $mail->isSMTP();

        $mail->Host = gethostbyname("smtp.gmail.com");
        $mail->Port=587;
        $mail->SMTPAuth=true;
        $mail->Username="php.project.1234@gmail.com";
        $mail->Password="php1234php";

        $mail->SMTPSecure="ssl";
        $mail->SMTPOptions = array(
            'ssl' => array(
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true
            )
        );
        $mail->CharSet = 'UTF-8';
        $mail->Encoding = 'base64';
        $mail->setFrom('php.project.1234@gmail.com',"Воинский учет");

        $mail->SMTPSecure = \PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;


//Set an alternative reply-to address
        $mail->addReplyTo('php.project.1234@gmail.com', 'First Last');

//Set who the message is to be sent to
        $mail->addAddress($email, 'Воинский учет');
//Set the subject line
        $mail->Subject = 'PHPMailer GMail SMTP test';


        $mail->AltBody = 'This is a plain-text message body';
        $mail->Body=$com;


        if (!$mail->send()) {
            echo 'Mailer Error: ' . $mail->ErrorInfo;
        } else {
            //Section 2: IMAP
            //Uncomment these to save your message in the 'Sent Mail' folder.
            #if (save_mail($mail)) {
            #    echo "Message saved!";
            #}
        }
        return view('comments') ;
    }

    public function spravka_is(){
        $spravka = DB::table('contacts')->get();
        return view('spravka1',['spravka'=> $spravka]);

    }

    public function confirmed_certificates(){
        $spravka2 = DB::table('contacts')->get();
        $g_row3=  DB::table('referencesses')->get();
        return view('spravka2',['spravka2'=>$spravka2],['g_row3'=>$g_row3]);
    }

    public function addpdf(Request $request){


        $toaddpdf = $_POST['toaddpdf'];
        $refname = $_POST['refname'];

        $data = DB::table('contacts')->get();
        foreach ($data as $row1){
            $name = $row1->name;
            $surname = $row1->surname;
            $lastname = $row1->lastname;
            $birthdate = $row1->birthday;
            $place = $row1->place;
            $education = $row1->education;
            $special =  $row1->special;
            $sport = $row1->sports_category;
            $wife = $row1->wife;
        }
        $table2 = new issued_certificates();
        $table2->reference_id = $request ->input($refname);
        $table2->stud_id = $request ->input($toaddpdf);
        $table2->time_is = $request->input(date("Y-n-j"));

        $pdf = new PDF(true);
        if($refname == 1) {
            $html = "
<style type='text/css'>
                body{
                align-items: center;
        width: 800px;
        font-family:DejaVu Sans,sans-serif;
    }
</style>
<div class='main' style='width:  700px'>
<div class='first' style='float: right; margin-bottom: 20px'>
    <h6>Приложение 1</h6>
    <h4>к Правилам о порядке <br>
        ведения воинского<br>
        учета военнообязанных и призывников<br>
        в Республике Казахстан</h4>
        </div>
        <div class='second' style='margin-top: 250px'>
            <h5 style='text-align: center'>Форма N 1</h5>
            <p style='ma'>Фамилия:________________<u>$surname</u>______________</p>
            <p>Имя:________________<u>$name</u>______________</p>
            <p>Отчество:________________<u>$lastname</u>______________</p>
            <p>Адрес:________________<u>$place</u>______________</p>

            <br>
            <h5 style='text-align: center'>I. Общие сведения</h5>
            <p>1. Место рождения:________________<u>$place</u>______________</p>
            <p>2. Образование:________________<u>$education</u>______________</p>
            <p>3. Гражданские специальности:________________<u>$special</u>______________</p>
            <p>4. Наличие первого спортивного разряда или спортивного звания:________________<u>$sport</u>______________
            </p>
            <p>5. Семейное положение ________________<u>$wife</u>______________</p>
                    </div>
                    </div>
                    ";
            
            $pdf ->loadHtml($html);
            $pdf ->setPaper('a4', 'landscape');


        }

        $com = DB::table("udos")->get();
        foreach ($com as $c){
            if ($place=="Алматы" and $c->id == 1){
                $commisname = $c->name;
            }
            if ($place=="Шымкент" and $c->id == 3){
                $commisname = $c->name;
            }
            if ($place=="Нур-Султан" and $c->id ==  4){
                $commisname = $c->name;
            }
            if ($place=="Актобе" and $c->id ==  5){
                $commisname = $c->name;
            }if ($place=="Семей" and $c->id ==  6){
                $commisname = $c->name;
            }
            if ($place=="Караганда" and $c->id ==  7){
                $commisname = $c->name;
            }
        }
        if($refname == 2){
            $html = "<style type='text/css'>
    body{
        align-items: center;
        width: 800px;
        font-family:DejaVu Sans,sans-serif;
    }
</style>
<div class='main' style='width:  700px'>
<div class='first' style='float: right; margin-bottom: 20px'>
    <h6>Приложение 2</h6>
    <br>
    <h4>к Правилам о порядке  <br>
        ведения воинского<br>
        учета военнообязанных и призывников<br>
        в Республике Казахстан</h4>

        </div>
        <div class='second' style='margin-top: 250px'>
            <h5 style='text-align: center'>СВОДНЫЙ СПИСОК</h5>

           <table>
               <tr>
               <th>№<br>п/п</th>
               <th>Фамилия,имя и отчество</th>
               <th>Образование</th>
               <th>Место жительства</th>
               <th>Отметка управления (отдела) по делам обороны <br>
                о дате приписки к призывному участку
                  <br>и под каким порядковым номером записан в протоколе призывник</th>
               </tr>
               <tr>
               <th>1</th>
               <th>2</th>
               <th>3</th>
               <th>4</th>
               <th>5</th>
                </tr>
                <tr>
                <td>1</td>
                <td>$surname, $name <br> $lastname</td>
                <td>$education</td>
                <td>$place</td>
                <td>$commisname</td>
                </tr>

</table>

            <br>
            <h5 style='text-align: center'>I. Общие сведения</h5>
            <p>1. Место рождения:________________<u>$place</u>______________</p>
            <p>2. Образование:________________<u>$education</u>______________</p>
            <p>3. Гражданские специальности:________________<u>$special</u>______________</p>
            <p>4. Наличие первого спортивного разряда или спортивного звания:________________<u>$sport</u>______________
            </p>
            <p>5. Семейное положение ________________<u>$wife</u>______________</p>
                    </div>
                    </div>
";
            $pdf ->loadHtml($html);
            $pdf ->setPaper('a4', 'landscape');


        }

         $pdf->render();

         // Output the generated PDF to Browser*/
        return $pdf->download('pdf_file.pdf');


    }

    public function reference_select(){
        $erwe = $_POST['idforref'];

        if (isset($_POST['ssss'])) {
            if ($erwe ==1) {
                return view('reference1');
            }
            if ($erwe ==2) {
                return view('reference2');
            }
        }

    }

    public function udo(){
        $udo = DB::table("udos")->get();
        return view('udo',['udo'=> $udo]);
    }

    public function delete_udo(){
        $del=DB::table('udos')->where('id', $_POST['idname'])->delete();
        return view('udo',['delete'=>$del]) ;

    }

    public function update_udo(){
        $edit_udo=DB::table("udos")->get();
        return view('update_udo',['edit_udo'=>$edit_udo]);
    }

    public function set_update(){
        $set_edit =DB::table('udos')->where('id',$_GET['idcommis'])
            ->update(array('name' => $_GET['nameof'],
                'address'=>$_GET['addressnameofcom'],
                'quantity' => $_GET['quantityofcom']));


        return view('udo',['edit_save'=>$set_edit]);
    }

    public function insert_udo(Request $request3){
        $new_udo = new Udo();
        $new_udo ->name = $request3 -> input('name');
        $new_udo ->address = $request3 -> input('address');
        $new_udo ->quantity = $request3 -> input('quantity');

        $new_udo->save();
        return redirect()->route('udo');
    }


    public function download(){
        $file="law.docx";
        return response()->download($file);
        return view('pravila');
    }
}
