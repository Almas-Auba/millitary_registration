<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/', function () {
    return view('index');
});

Route::get('/edit', function () {
    return view('edit_db');
});

Route::get('/students_list', function () {
    return view('students_list');
});
Route::get('/spravka', function () {
    return view('spravka');
});


Route::get('/contacts', function () {
    return view('contacts');
})->name('contacts');

Route::get('/register',function (){
    return view('register');
})->name('register');

use App\Http\Controllers\MainController;
Route::post('/register/new',[MainController::class,'register_new']);


Route::post("/comment",[MainController::class,'comment']);

Route::post('/students_list',[MainController::class,'students_list']);

Route::post('/filter',[MainController::class,'filter']);

Route::post('/search',[MainController::class,'search']);

Route::post('/edit_con',[MainController::class,'edit_con']);

Route::post('edit_db2',[MainController::class,'edit_db2']);

Route::post('/edit_save',[MainController::class,'edit_save']);

Route::post('/adminproverka',[MainController::class,'adminproverka']);

Route::post('/delete',[MainController::class,'delete_admin_stu']);

Route::get('/adminpage', function () {
    return view('adminpage');
});


Route::get('/admin_spravka', function () {
    $spr = DB::table('referencesses')->get();
    return view('admin_spr',['spr'=>$spr]);
})->name('admin_spravka');;

Route::post('/delete_spr',[MainController::class,'delete_admin_spr']);

Route::get('/add_spr',function (){
    return view('add_spr');
});

Route::get('/ref_issues',function (){
    $spr1 = DB::table('issued_certificates')->get();
    $spr2 = DB::table('referencesses')->get();
    $spr3 = DB::table('contacts')->get();
    return view('ref_issues',['spr1'=>$spr1],['$spr2'=>$spr2],['$spr3'=>$spr3]);
});

Route::get('/insert_spr',[MainController::class,'add_admin_spr']);

Route::get('/comments', function (){
    return view('comments');
})->name('comments');

Route::post('/open_comment', function (){
    return view('open_comment');
});

Route::post('/send_mess',[MainController::class,'send_mess']);

Route::post('/spravka_is',[MainController::class,'spravka_is']);

Route::post('/confirmed_certificates',[MainController::class,'confirmed_certificates']);

Route::post('/addpdf',[MainController::class,'addpdf']);

Route::post('/reference_select',[MainController::class,'reference_select']);

Route::get('/udo',[MainController::class,'udo'])->name('udo');

Route::post('/delete_udo',[MainController::class,'delete_udo']);

Route::post('/update_udo',[MainController::class,'update_udo']);

Route::get('/set_update',[MainController::class,'set_update']);

Route::get('/add_udo',function () {
    return view('add_udo');
});

Route::post('/insert_udo',[MainController::class,'insert_udo']);

Route::get('/pravila',function (){
    return view('pravila');
});

Route::get('/download',[MainController::class,'download']);




