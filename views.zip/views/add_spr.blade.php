@extends('header_admin')
@section('admin_content')
        <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom" style="background: rgba(209,179,102,0.53);">
            <h1 class="h2">Воинский учет</h1>
            <div class="btn-toolbar mb-2 mb-md-0">
                <div class="btn-group mr-2">
                    <a class="btn btn-sm btn-outline-secondary" href="/add_spr">Добавить</a>
                </div>
            </div>
        </div>
        <h2 style="background: rgba(209,179,102,0.53);">Добавить справку</h2>
        <form  action="/insert_spr" method="get">
            @csrf
            <div class="form-group mt-auto">
            <label >Название</label>
            <input type="text" class="form-control" name="name">
            <label >Описание</label>
            <input type="text" class="form-control" name="description">
            <label >Орган выдачи</label>
            <input type="text" class="form-control" name="issued">
            <button type="submit" class="btn btn-sm btn-outline-secondary mt-3"  >Добавить справку</button>
        </div>
        </form>

@endsection
