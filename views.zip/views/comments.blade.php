@extends('header_admin')
@section('admin_content')
        <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom" style="background: rgba(209,179,102,0.53);">
            <h1 class="h2">Воинский учет</h1>
        </div>
        <h2 style="background: rgba(209,179,102,0.53);">Список отзывов</h2>
        <div class="table-responsive" style="background: rgba(209,179,102,0.53);">
            <table class="table table-striped table-sm">
                <thead>
                <tr>
                    <th>№</th>
                    <th>Пользователь</th>
                    <th>Время получение</th>
                </tr>
                </thead>
                <tbody>
                <?php
                use Illuminate\Support\Facades\DB;
                $g_row = DB::table('comment_c_s')->get();
                $edit_save = DB::table('comment_c_s')->where('prosmotr',0)
                   ->update(array('prosmotr' => 1));
                foreach($g_row as $row)
                {
                    ?>
                    <form action="/open_comment" method="post">
                        @csrf
                        <tr>
                            <th scope="row"><?php echo($row->id)?></th>
                            <td><?php echo($row->email)?></td>
                            <td><?php echo($row->time_com)?></td>
                            <input type="hidden" name="idd" value="<?=$row->id?>">
                            <td><input type="submit" class="form-control btn-danger btn-outline-light" value="Открыть" name="open"/></td>
                        </tr>
                    </form>
                    <?php
                }

                ?>
                </tbody>
            </table>
        </div>

@endsection
