@extends('header')
@section('title')
    <title>Контакты</title>
@endsection
@section('main_content')
<div class="container mb-5 bg-light rounded">
    <h1 class="text-center mb-5 mt-3">Контактные данные</h1>
    <div class="row mt-5">
        <div class="col-md-6 mb-4 ">
            <div class="card card-cascade narrower bg-dark">
                <div class="card-body card-body-cascade text-center">
                    <div id="map-container-google-9" class="z-depth-1-half map-container-5" style="height: 600px">
                        <iframe src="https://maps.google.com/maps?q=IITU&t=&z=13&ie=UTF8&iwloc=&output=embed" width="400px" height="600px" frameborder="0"
                                style="border:0" allowfullscreen></iframe>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6 ">
            <div class=" d-flex justify-content-between ">
                <div class="d-flex flex-column bd-highlight mb-3 ">
                    <div class="p-2 bd-highlight"><h4>Callcenter</h4></div>
                    <div class="p-2 bd-highlight"><h4>Приемная УДО</h4></div>
                    <div class="p-2 bd-highlight"><h4>Департамент мобилизации</h4></div>
                    <div class="p-2 bd-highlight"><h4>Официальный</br>сайт</h4></div>
                    <div class="p-2 bd-highlight"><h4>Адрес</h4></div>
                </div>
                <div class="d-flex flex-column bd-highlight ">
                    <div class="p-3 bd-highlight"><a href="">+7(727) 255 00 00</a></div>
                    <div class="p-3 bd-highlight"><a href="">+7(727) 200 00 01</a></div>
                    <div class="p-2 bd-highlight"><a href="">+7(727) 500 50 05</a></div>
                    <div class="p-3 bd-highlight"><a href="">iitu.kz</a></div>
                    <div class="p-4 bd-highlight"><a href="">улица Манаса 8 ,</br> Алматы 050000</a></div>
                </div>
            </div>
            <div class="form-group font-weight-bold " >
                <form action="/comment" method="post" >
                    @csrf
                    <label for="email">Электронная почта или телефон</label>
                    <input type="text" id="email" class="form-control bg-dark text-light" name="email">
                    <label for="otziv" >Вопросы и отзывы </label>
                    <textarea class="form-control bg-dark text-light" name="review" id="otziv" cols="40" rows="9"></textarea>
                    <button type="submit" class="btn btn-dark btn-outline-light mt-3 float-right mb-5" >Отправить</button>
                </form>
            </div>
        </div>

    </div>
</div>
@endsection
