
@extends('header')

@section('main_content')
<?php
    use Illuminate\Support\Facades\DB;
    $iin=$_POST['inn2'];
    $edit_con = DB::table('contacts')->get();
    $email=222;
    foreach ($edit_con as $row){
        if(($row->inn)==$iin){
            $email=$row->email;
        }
    }
    if ($email!=222){
$kkk=rand(99999,999999);
$secret=hash('ripemd160', 'mycode'.$kkk);
$mail= new \PHPMailer\PHPMailer\PHPMailer(true);
$mail->isSMTP();
$mail->Host = gethostbyname("smtp.gmail.com");
$mail->Port=587;
$mail->SMTPAuth=true;
$mail->Username="php.project.1234@gmail.com";
$mail->Password="php1234php";
$mail->SMTPSecure="ssl";
$mail->SMTPOptions = array(
    'ssl' => array(
        'verify_peer' => false,
        'verify_peer_name' => false,
        'allow_self_signed' => true
    )
);
$mail->CharSet = 'UTF-8';
$mail->Encoding = 'base64';
$mail->setFrom('php.project.1234@gmail.com',"Воинский учет");
$mail->SMTPSecure =\PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
//Set an alternative reply-to address
$mail->addReplyTo('php.project.1234@gmail.com', 'First Last');
//Set who the message is to be sent to
$mail->addAddress($email, 'Код');
//Set the subject line
$mail->Subject = 'PHPMailer GMail SMTP test';
$mail->AltBody = 'This is a plain-text message body';
$mail->Body="Чтобы получить доступ к вашем данным введите этот код\n".$kkk;
if (!$mail->send()) {
    echo 'Mailer Error: ' . $mail->ErrorInfo;
} else {

    //Section 2: IMAP
    //Uncomment these to save your message in the 'Sent Mail' folder.
    #if (save_mail($mail)) {
    #    echo "Message saved!";
    #}
}



?>
    <div class="container mb-5 ">
        <div class="form-group w-50 ">
            <p>На вашу электронную почту <span><?=$email?></span> отправлен код подтверждения, подтвердите его</p>
            <form action="/edit_db2" method="post">
                @csrf
                <label for="name" class="btn-outline-dark  font-weight-bold " style="font-size: 22px">Код подтверждения</label>
                <input type="hidden" name="inn2" class="form-control" value=<?=$secret?> >
                <input type="hidden" name="inn22" class="form-control" value=<?=$iin?> >
                <input type="text" name="code" class="form-control" >
                <button class="btn btn-outline-light mt-3" >Отправить</button>
            </form>
        </div>
    </div>
</div>
<?php
}
    else{
        ?>

<div class="container mb-5 ">
    <div class="form-group w-50 ">
        <p>Ваш ИИН не найдена , попробуйте еще раз</p>
        <form action="/edit" method="get">
            @csrf
            <button class="btn btn-outline-light mt-3" >Отправить занова</button>
        </form>
    </div>
</div>
</div>


<?php



    }
    ?>


@endsection
