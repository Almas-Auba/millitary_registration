@extends('header')
@section('title')
    <title>Изменение данных</title>
@endsection
@section('main_content')
<div class="container mt-5 ">
        <div class="form-group w-50  mt-5">
            <form action="/edit_con" method="post">
                @csrf
            <label for="name" class="btn-outline-dark  font-weight-bold " style="font-size: 22px">ИИН студента</label>
            <input type="text" name="inn2" class="form-control" value=" ">
            <button class="btn btn-outline-light mt-3" >Изменить</button>
            </form>
        </div>
</div>
<script
    src="https://code.jquery.com/jquery-3.5.1.min.js"
    integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0="
    crossorigin="anonymous"></script>

@endsection


