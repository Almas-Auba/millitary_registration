@extends('header')

@section('main_content')
<div class="container mb-5">
    <?php
    use Illuminate\Support\Facades\DB;

    $code=$_POST['code'];
    $code22=hash('ripemd160', 'mycode'.$code);
    $sec=$_POST['inn2'];
    $iin=$_POST['inn22'];
    if ($code22!=$sec) {
        ?>
        <p>Код неправильный попробуйте занова!</p>
        <form action="/edit_con" method="post">
            @csrf
            <input type="hidden" name="inn2" value=<?=$iin?> >
            <button class="btn btn-outline-light mt-3" >Отправить занова</button>
        </form>
    <?php
            }
    else{
    $edit_db2 = DB::table('contacts')->get();
    foreach($edit_db2 as $row)
    {
        if (($row->inn)==$iin){
    ?>
        <form action="/edit_save" method="post">
            @csrf
            <div class="row mt-5 justify-content-center">
                <div class="col-6 display-4">
                    <div class="form-group m-0 ">
                        <label for="name" class="btn-outline-dark  font-weight-bold " style="font-size: 22px">Имя</label>
                        <input type="text" name="name" id="name" class="form-control" value="<?=$row->name?>"></div>
                    <div class="form-group m-0 ">
                        <label for="surname" class="btn-outline-dark  font-weight-bold " style="font-size: 22px">Фамилия</label>
                        <input type="text" name="surname" id="surname" class="form-control" value="<?=$row->surname?>">
                    </div>
                    <div class="form-group m-0 ">
                        <label for="lastname" class="btn-outline-dark  font-weight-bold " style="font-size: 22px">Отчество</label>
                        <input type="text" name="lastname" id="lastname" class="form-control" value="<?=$row->lastname?>">
                    </div>
                    <div class="form-group m-0 ">
                        <label for="birthday" class="btn-outline-dark  font-weight-bold " style="font-size: 22px"> Дата рождения</label>
                        <input type="date" name="birthday" id="birthday" class="form-control" value="<?=$row->birthday?>">
                    </div>
                    <div class="form-group m-0 ">
                        <label for="inn" class="btn-outline-dark  font-weight-bold " style="font-size: 22px">ИИН</label>
                        <input type="text" name="inn" id="inn" class="form-control" value="<?=$iin?>"></div>
                    <div class="form-group m-0 ">
                        <label for="place" class="btn-outline-dark  font-weight-bold " style="font-size: 22px">Место жительства или временного пребывания</label>
                        <input type="text" name="place" id="place" class="form-control" value="<?=$row->place?>"></div>
                    <div class="form-group m-0 ">
                        <label for="wife" class="btn-outline-dark  font-weight-bold " style="font-size: 22px">Cемейное положение</label>
                        <input type="text" name="wife" id="wife" class="form-control " value="<?=$row->wife?>"></div>
                    <div class="form-group m-0 ">
                        <label for="order" class="btn-outline-dark  font-weight-bold " style="font-size: 22px">Воинское звание</label>
                        <input type="text" name="order" id="order" class="form-control" value="<?=$row->order?>"></div>

                    <div class="form-group m-0 ">
                        <label for="education" class="btn-outline-dark  font-weight-bold " style="font-size: 22px">Образование</label>
                        <input type="text" name="education" id="education" class="form-control" value="<?=$row->education?>">
                    </div>
                    <div class="form-group m-0 " >
                        <label for="nation" class="btn-outline-dark  font-weight-bold " style="font-size: 22px"> Национальность</label>
                        <input type="text" name="nation" id="nation" class="form-control" value="<?=$row->nation?>">
                    </div>
                    <div class="form-group m-0 ">
                        <label for="special" class="btn-outline-dark  font-weight-bold " style="font-size: 22px">Гражданская специальность</label>
                        <input type="text" name="special" id="special" class="form-control" value="<?=$row->special?>">
                    </div>
                    <div class="form-group m-0 ">
                        <label for="military" class="btn-outline-dark  font-weight-bold " style="font-size: 22px">Военная подготовка</label>
                        <input type="text" name="military" id="military" class="form-control" value="<?=$row->military?>">
                    </div>
                    <div class="form-group m-0 ">
                        <label for="sports_category" class="btn-outline-dark  font-weight-bold " style="font-size: 22px">Спортивный разряд</label>
                        <input type="text" name="sports_category" id="sports_category" class="form-control" value="<?=$row->sports_category?>">
                    </div>
                    <div class="form-group m-0 ">
                        <label for="postponement" class="btn-outline-dark  font-weight-bold " style="font-size: 22px">Отсрочка</label>
                        <input type="text" name="postponement" id="postponement" class="form-control" value="<?=$row->postponement?>">
                    </div>
                    <div class="form-group m-0 " >
                        <label for="conviction" class="btn-outline-dark  font-weight-bold " style="font-size: 22px">Судимость</label>
                        <input type="text" name="conviction" id="conviction" class="form-control" value="<?=$row->conviction?>">
                    </div>
                    <div class="form-group m-0 ">
                        <label for="email" class="btn-outline-dark  font-weight-bold " style="font-size: 22px">Электронная почта или телефон</label>
                        <input type="text" name="email" id="email" class="form-control mb-3" value="<?=$row->email?>"><br>
                    </div>
                </div>
                <input type="hidden" name="id" value="<?=$row->id?>">
                <input type="submit" class="btn btn-light form-control w-75 ">
            </div>
        </form>
    <?php   }
            }
        }
    ?>
</div>
@endsection


