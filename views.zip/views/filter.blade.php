@extends('header')

@section('main_content')
<main class="mb-5">
    <div class="container ">
        <div>
            <form method="post" action="/filter" class="d-flex m-3">
                @csrf
                <input type="text" class="form-control " name="fname" placeholder="Введите Имя...">
                <input type="text" class="form-control ml-2"  name="fsurname" placeholder="Введите Фамилию...">
                <input type="text" class="form-control ml-2"  name="fiin" placeholder="Введите ИИН...">
                <input type="submit" class="form-control ml-2" value="Фильтр" >
            </form>
        </div>
        <table class="table">
            <thead class="thead-light">
            <tr>
                <th scope="col">#</th>
                <th scope="col">Имя</th>
                <th scope="col">Отчество</th>
                <th scope="col">Фамилия</th>
                <th scope="col">Дата рождения</th>
                <th scope="col">ИИН</th>
                <th scope="col">Образование</th>
            </tr>
            </thead>
            <tbody>
            <?php

            use Illuminate\Support\Facades\DB;

            if(!empty($_POST['fname']) and empty($_POST['fsurname']) and  empty($_POST['fiin'])){
            $name=$_POST['fname'];
            $filter = DB::table('contacts')->where('name', 'like', "$name%")
                ->get();
                foreach($filter as $row)
                {
                    ?>
                    <tr>
                        <th scope="row">{{$row->id}}</th>
                        <td>{{$row->name}}</td>
                        <td>{{$row->lastname}}</td>
                        <td>{{$row->surname}}</td>
                        <td>{{$row->birthday}}</td>
                        <td>{{$row->inn}}</td>
                        <td>{{$row->education}}</td>
                    </tr>
                    <?php
                }
            }
               if(!empty($_POST['fsurname']) and empty($_POST['fname']) and empty($_POST['fiin']) ){
                    $surname =$_POST['fsurname'];
                    $filter = DB::table('contacts')->where('surname', 'like', "$surname%")
                        ->get();
                    foreach($filter as $row)

                    {
                        ?>


                        <tr>
                            <th scope="row">{{$row->id}}</th>
                            <td>{{$row->name}}</td>
                            <td>{{$row->lastname}}</td>
                            <td>{{$row->surname}}</td>
                            <td>{{$row->birthday}}</td>
                            <td>{{$row->inn}}</td>
                            <td>{{$row->education}}</td>
                        </tr>
                        <?php
                  }
                }
            if(!empty($_POST['fiin']) and empty($_POST['fsurname']) and empty($_POST['fname'])){
                        $inn =$_POST['fiin'];
                        $filter = DB::table('contacts')->where('inn', 'like', "$inn%")
                            ->get();
                        foreach($filter as $row)
                {
                    ?>
                    <tr>
                        <th scope="row">{{$row->id}}</th>
                        <td>{{$row->name}}</td>
                        <td>{{$row->lastname}}</td>
                        <td>{{$row->surname}}</td>
                        <td>{{$row->birthday}}</td>
                        <td>{{$row->inn}}</td>
                        <td>{{$row->education}}</td>
                    </tr>
                    <?php
                }
            }

            if(!empty($_POST['fname']) and !empty($_POST['fsurname']) and empty($_POST['fiin'])){
                    $name=$_POST['fname'];
                    $surname =$_POST['fsurname'];
                    $filter = DB::table('contacts')
                        ->where('name', 'like', "$name%")
                        ->where( 'surname','like',"$surname%")
                        ->get();
                    foreach($filter as $row)
                    {
                    ?>
                        <tr>
                            <th scope="row">{{$row->id}}</th>
                            <td>{{$row->name}}</td>
                            <td>{{$row->lastname}}</td>
                            <td>{{$row->surname}}</td>
                            <td>{{$row->birthday}}</td>
                            <td>{{$row->inn}}</td>
                            <td>{{$row->education}}</td>
                        </tr>
                    <?php
                }
            }
            if(!empty($_POST['fsurname']) and !empty($_POST['fiin']) and empty($_POST['fname'])){
                    $surname =$_POST['fsurname'];
                    $inn =$_POST['fiin'];
                    $filter = DB::table('contacts')
                        ->where('name', 'like', "$name%")
                        ->where('surname','like',"$surname%")
                        ->get();
                    foreach($filter as $row)
                    {
                        ?>
                    <tr>
                        <th scope="row">{{$row->id}}</th>
                        <td>{{$row->name}}</td>
                        <td>{{$row->lastname}}</td>
                        <td>{{$row->surname}}</td>
                        <td>{{$row->birthday}}</td>
                        <td>{{$row->inn}}</td>
                        <td>{{$row->education}}</td>
                    </tr>
                    <?php
               }
            }
            if(!empty($_POST['fname']) and !empty($_POST['fsurname']) and !empty($_POST['fiin'])){
                    $name=$_POST['fname'];
                    $surname =$_POST['fsurname'];
                    $inn =$_POST['fiin'];
                    $filter = DB::table('contacts')
                        ->where('name', 'like', "$name%")
                        ->where('surname','like',"$surname%")
                        ->where('inn','like',"$inn%")
                        ->get();
                    foreach($filter as $row)
                    {
                    ?>
                        <tr>
                            <th scope="row">{{$row->id}}</th>
                            <td>{{$row->name}}</td>
                            <td>{{$row->lastname}}</td>
                            <td>{{$row->surname}}</td>
                            <td>{{$row->birthday}}</td>
                            <td>{{$row->inn}}</td>
                            <td>{{$row->education}}</td>
                        </tr>
                    <?php
               }
            }


            ?>
            </tbody>
        </table>
    </div>


</main>
@endsection
