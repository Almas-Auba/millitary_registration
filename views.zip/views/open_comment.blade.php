@extends('header_admin')
@section('admin_content')
        <div class="d-flex justify-content-between pl-2 flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom" style="background: rgba(209,179,102,0.53);">
            <h1 class="h2">Воинский учет</h1>
        </div>
        <h2 class="pl-2"  style="background: rgba(209,179,102,0.53);">Список отзывов</h2>
        <div class="table-responsive" style="background: rgba(209,179,102,0.53);">
            <div class="form-group pl-2 pr-2">
                <?php
                $id=$_POST['idd'];
                use Illuminate\Support\Facades\DB;
                $g_row =  DB::table('comment_c_s')->get();
                foreach($g_row as $row)
                {
                    if (($row->id)==$id){
                        $com=$row;
                    }
                }

                ?>
                <h3 >Пользователь  <?=($com->email)?>  </h3>
                <div class="form-group h-250 border border-dark rounded p-4 bg-dark text-light ">
                <p>
                    <?=($com->review)?>
                </p>
                </div>
                <span><?=($com->time_com)?></span>
                <br>

                <h4>Ответить</h4>
                <form action="/send_mess" method="post">
                    @csrf
                    <input type="hidden" name="email" value="<?=($com->email)?>">
                    <textarea type="text"  name="mess" class="form-control "></textarea>
                    <button type="submit" class="btn btn-dark btn-outline-light float-right mt-2 mb-5" >Отправить</button>
                </form>
            </div>
        </div>

@endsection

