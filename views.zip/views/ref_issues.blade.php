@extends('header_admin')
@section('admin_content')

        <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom" style="background: rgba(209,179,102,0.53);">
            <h1 class="h2">Воинский учет</h1>
        </div>
        <h2 style="background: rgba(209,179,102,0.53);">Выданные справки</h2>
        <div class="table-responsive" style="background: rgba(209,179,102,0.53);">
            <table class="table table-striped table-sm">
                <thead>
                <tr>
                    <th>Имя</th>
                    <th>Фамилия</th>
                    <th>Отчество</th>
                    <th>Описание справки</th>
                    <th>время выдачи</th>
                </tr>
                </thead>
                <tbody>
                <?php
                    use Illuminate\Support\Facades\DB;
                $spr1 = DB::table('issued_certificates')->get();
                foreach($spr1 as $row){
                    $spr2 = DB::table('referencesses')->get();
                    $spr3 = DB::table('contacts')->get();
                    foreach ($spr3 as $row3) {
                        if (($row->stud_id) == ($row3->id)) {
                            $stu=$row3;
                        }
                    }
                    foreach ($spr2 as $row2) {
                        if (($row->reference_id) == ($row2->id)) {
                            $ref=$row2;
                        }
                    }
                    ?>
                    <tr>
                            <th scope="row"><?php

                                echo $stu->name;

                            ?></th>
                            <td><?php
                                    echo $stu->surname;
                                    ?>
                            </td>
                            <td><?php echo $stu->lastname;
                                  ?></td>
                            <td><?php    echo($ref->name);
                            ?></td>
                            <td><?php echo($row->time_is)?></td>
                        </tr>
                    <?php
                    }
                ?>
                </tbody>
            </table>
        </div>

@endsection
