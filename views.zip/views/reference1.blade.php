@extends('header_admin')

@section('admin_content')
        <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom" style="background: rgba(209,179,102,0.53);">
            <h1 class="h2">Воинский учет</h1>
            <div class="btn-toolbar mb-2 mb-md-0">
                <div class="btn-group mr-2">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-8 bg-light rounded p-3 mb-5">
                <h4 class=" float-right text-center">к Правилам о порядке  <br>
                    ведения воинского<br>
                    учета военнообязанных и призывников<br>
                    в Республике Казахстан</h4>
            </div>
            <div class="col-8 bg-light rounded p-3 ml-5">
                <h5 class="text-center mb-5">Форма N 1</h5>
                <p>Фамилия:_________________________________________</p>
                <p>Имя:_____________________________________________</p>
                <p>Отчество:________________________________________</p>
                <p>Адрес:___________________________________________</p>

                <br>
                <h5 class="text-center mb-5">I. Общие сведения</h5>
                <p>1. Место рождения:_________________________________________</p>
                <p>2. Образование:____________________________________________</p>
                <p>3. Гражданские специальности:______________________________</p>
                <p>4. Наличие первого спортивного разряда или спортивного звания:______________________________
                </p>
                <p>5. Семейное положение _____________________________________</p>

    </main>
        </div>
        </div>
@endsection

