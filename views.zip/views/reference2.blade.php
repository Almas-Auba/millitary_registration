@extends('header_admin')

@section('admin_content')
        <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom" style="background: rgba(209,179,102,0.53);">
            <h1 class="h2">Воинский учет</h1>
            <div class="btn-toolbar mb-2 mb-md-0">
                <div class="btn-group mr-2">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-8 bg-light rounded p-3 mb-5">
                <h4 class=" float-right text-center">к Правилам о порядке  <br>
                    ведения воинского<br>
                    учета военнообязанных и призывников<br>
                    в Республике Казахстан</h4>
            </div>
            <div class="col-8 bg-light rounded p-3 ml-5">
                <table>
                    <tr>
                        <th>№<br>п/п</th>
                        <th>Фамилия,имя и отчество</th>
                        <th>Образование</th>
                        <th>Место жительства</th>
                        <th>Отметка управления (отдела) по делам обороны
                            <br>
                            о дате приписки к призывному участку
                            <br>и под каким порядковым номером записан в протоколе призывник</th>
                    </tr>
                    <tr>
                        <th>1</th>
                        <th>2</th>
                        <th>3</th>
                        <th>4</th>
                        <th>5</th>
                    </tr>
                    <tr>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                </table>
                <br>
            </div>
                <div class="ml-5" style="margin-top: 100px">
                <h5 class="text-center mb-5">I. Общие сведения</h5>
                <p>1. Место рождения:_________________________________________</p>
                <p>2. Образование:____________________________________________</p>
                <p>3. Гражданские специальности:______________________________</p>
                <p>4. Наличие первого спортивного разряда или спортивного звания:______________________________
                </p>
                <p>5. Семейное положение _____________________________________</p>
                </div>

    </main>
</div>
@endsection
