@extends('header')
@section('title')
    <title>Регистрация</title>
@endsection
@section('main_content')

<div class="container mb-3">
    <?php
    $ff=request('parameter');
    if($ff==111){
        ?>

        <div class="modal fade show" id="myModal" tabindex="-1" role="dialog" >
            <div class="modal-dialog " role="document">
                <div class="modal-content border-success">
                    <div class="modal-header ">
                        <h5 class="modal-title ">Пользователь доваблен!</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-outline-success" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
        <script>
            $(".modal").modal("show");
        </script>
    <?php  }
    ?>
    <h1 class="text-center"> Введите ваши данные</h1>
    <form action="/register/new" method="post">
        @csrf
    <div class="row justify-content-center">
        <div class="col-4 display-6">
                <div class="form-group">
                    <label for="name" class="btn-outline-dark  font-weight-bold " style="font-size: 22px">Имя</label>
                    <input type="text" name="name" id="name" class="form-control">
                </div>
                <div class="form-group">
                    <label for="surname" class="btn-outline-dark  font-weight-bold " style="font-size: 22px">Фамилия</label>
                    <input type="text" name="surname" id="surname" class="form-control">
                </div>
                <div class="form-group">
                    <label for="lastname" class="btn-outline-dark  font-weight-bold " style="font-size: 22px">Отчество</label>
                    <input type="text" name="lastname" id="lastname" class="form-control">
                </div>
                <div class="form-group">
                    <label for="birthday" class="btn-outline-dark  font-weight-bold " style="font-size: 22px"> Дата рождения</label>
                    <input type="date" name="birthday" id="birthday" class="form-control">
                </div>
            <div class="form-group">
                <label for="inn" class="btn-outline-dark  font-weight-bold " style="font-size: 22px">ИИН</label>
                <input type="text" name="inn" id="inn" class="form-control">
            </div>
            <div class="form-group">
                <label for="place" class="btn-outline-dark  font-weight-bold " style="font-size: 22px">Место жительства </label>
                <input type="text" name="place" id="place" class="form-control">
            </div>
            <div class="form-group">
                <label for="wife" class="btn-outline-dark  font-weight-bold " style="font-size: 22px">Cемейное положение</label>
                <input type="text" name="wife" id="wife" class="form-control">
            </div>
            <div class="form-group">
                <label for="order" class="btn-outline-dark  font-weight-bold " style="font-size: 22px">Воинское звание</label>
                <input type="text" name="order" id="order" class="form-control"></div>
        </div>
        <div class="col-4 display-6">
            <div class="form-group">
                <label for="education" class="btn-outline-dark  font-weight-bold " style="font-size: 22px">Образование</label>
                <input type="text" name="education" id="education" class="form-control">
            </div>
            <div class="form-group">
                <label for="nation" class="btn-outline-dark  font-weight-bold " style="font-size: 22px"> Национальность</label>
                    <input type="text" name="nation" id="nation" class="form-control">
            </div>
            <div class="form-group">
                <label for="special" class="btn-outline-dark  font-weight-bold " style="font-size: 22px">Гражданская специальность</label>
                <input type="text" name="special" id="special" class="form-control">
            </div>
            <div class="form-group">
                <label for="military" class="btn-outline-dark  font-weight-bold " style="font-size: 22px">Военная подготовка</label>
                <input type="text" name="military" id="military" class="form-control">
            </div>
            <div class="form-group">
                <label for="sports_category" class="btn-outline-dark  font-weight-bold " style="font-size: 22px">Спортивный разряд</label>
                <input type="text" name="sports_category" id="sports_category" class="form-control">
            </div>
            <div class="form-group">
                <label for="postponement" class="btn-outline-dark  font-weight-bold " style="font-size: 22px">Отсрочка</label>
                <input type="text" name="postponement" id="postponement" class="form-control">
            </div>
            <div class="form-group">
                <label for="conviction" class="btn-outline-dark  font-weight-bold " style="font-size: 22px">Судимость</label>
                <input type="text" name="conviction" id="conviction" class="form-control">
            </div>
            <div class="form-group">
                <label for="email" class="btn-outline-dark  font-weight-bold " style="font-size: 22px">Электронная почта</label>
                <input type="text" name="email" id="email" class="form-control mb-3"><br>
            </div>
        </div>
    </div>
        <div class="d-flex justify-content-center">
             <button type="submit" class="btn-sm  btn-outline-dark">Отправить</button>
        </div>
    </form>
</div>
@endsection
