@extends('header')
@section('title')
    <title>Поиск</title>
@endsection
@section('main_content')
    <div class="container">
        <table class="table">
            <thead class="thead-dark">
            <tr>
                <th scope="col">#</th>
                <th scope="col">Name</th>
                <th scope="col">Lastname</th>
                <th scope="col">Surname</th>
                <th scope="col">Birth Date</th>
                <th scope="col">Education</th>
            </tr>
            </thead>
            <tbody>
            <?php
            use Illuminate\Support\Facades\DB;

            if(!empty($_POST['search_area'])){
               $search=$_POST['search_area'];
            $filter = DB::table('contacts')->where('name', 'like', "$search%")
                ->get();
            foreach($filter as $row)
            {
            ?>
            <tr>
                <th scope="row">{{$row->id}}</th>
                <td>{{$row->name}}</td>
                <td>{{$row->surname}}</td>
                <td>{{$row->lastname}}</td>
                <td>{{$row->birthday}}</td>
                <td>{{$row->education}}</td>
            </tr>
            <?php
            }
            if(empty($filter)){
            $search=$_POST['search_area'];
            $filter = DB::table('contacts')->where('surname', 'like', "$search%")
                ->get();
            foreach($filter as $row)
            {
                    ?>
                    <tr>
                        <th scope="row">{{$row->id}}</th>
                        <td>{{$row->name}}</td>
                        <td>{{$row->surname}}</td>
                        <td>{{$row->lastname}}</td>
                        <td>{{$row->birthday}}</td>
                        <td>{{$row->education}}</td>
                    </tr>
                    <?php
                }
            }
            if(empty($filter)){
                    $search=$_POST['search_area'];
                    $filter = DB::table('contacts')->where('lastname', 'like', "$search%")
                        ->get();
                    foreach($filter as $row)
                    {
                    ?>
                    <tr>
                        <th scope="row">{{$row->id}}</th>
                        <td>{{$row->name}}</td>
                        <td>{{$row->surname}}</td>
                        <td>{{$row->lastname}}</td>
                        <td>{{$row->birthday}}</td>
                        <td>{{$row->education}}</td>
                    </tr>
            <?php
                }
            }
            if(empty($filter)){
            $search=$_POST['search_area'];
            $filter = DB::table('contacts')->where('inn', 'like', "$search%")
                ->get();
            foreach($filter as $row)
            {
            ?>
            <tr>
                <th scope="row">{{$row->id}}</th>
                <td>{{$row->name}}</td>
                <td>{{$row->surname}}</td>
                <td>{{$row->lastname}}</td>
                <td>{{$row->birthday}}</td>
                <td>{{$row->education}}</td>
            </tr>
            <?php
            }
            }
            }
            ?>
            </tbody>
        </table>
    </div>
</main>
@endsection
