@extends('header')
@section('title')
    <title>Справки</title>
@endsection
@section('main_content')

<div class="container mb-5 d-flex justify-content-center">
        <form method="post" action="/spravka_is">
            @csrf
        <div class="form-group ">
            <label for="iin3" class="btn-outline-dark  font-weight-bold " style="font-size: 22px">ИИН студента</label>
            <input type="number" name="iin3" class="form-control" value="">
            <input type="submit" class="form-control btn btn-outline-light mt-3" value="Далее">
        </div>
        </form>
</div>
@endsection

