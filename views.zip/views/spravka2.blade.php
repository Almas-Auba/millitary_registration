@extends('header')
@section('title')
    <title>Справки</title>
@endsection
@section('main_content')
<div class="container mb-5 ">
    <?php
    use Illuminate\Support\Facades\DB;
    $code=$_POST['code1'];
    $code22=hash('ripemd160', 'mycode'.$code);
    $sec=$_POST['secretiin'];
    $iin1=$_POST['codeactiv'];
    if ($code22!=$sec) {
    ?>
    <p>Код неправильный попробуйте занова!</p>
    <form action="/spravka_is" method="post">
        @csrf
        <input type="hidden" name="iin3" value="<?=$iin1?>">
        <button class="btn btn-outline-light mt-3">Отправить занова</button>
    </form>
    <?php
        }
        else{
        $spravka2 = DB::table('contacts')->get();
        foreach($spravka2 as $row)
        {
        if ($row->inn==$iin1){
        ?>
                <h1 class="text-center">Ваши данные</h1>
                <div class="row mt-5 border border-dark rounded p-5 justify-content-center">
                    <div class="col-3 ">
                        <p class="font-weight-bold">Имя</p><hr>
                        <p class="font-weight-bold">Фамилия</p><hr>
                        <p class="font-weight-bold">Отчество</p><hr>
                        <p class="font-weight-bold">Email</p><hr>
                        <p class="font-weight-bold">Адрес</p><hr>
                        <p class="font-weight-bold">Образование</p><hr>
                    </div>
                    <div class="col-3">
                        <p class="font-weight-bold"><?=$row->name?></p><hr>
                        <p class="font-weight-bold"><?=$row->surname?></p><hr>
                        <p class="font-weight-bold"><?=$row->lastname?></p><hr>
                        <p class="font-weight-bold"><?=$row->email?></p><hr>
                        <p class="font-weight-bold"><?=$row->place?></p><hr>
                        <p class="font-weight-bold"><?=$row->education?></p><hr>
                    </div>
                </div>
                <?php
            }
        }
        $g_row3=  DB::table('referencesses')->get();
        foreach ($g_row3 as $row3){
            ?>
        <form action="/addpdf" method="post" class="d-flex mt-3">
            @csrf
            <h3 class="mr-5">Скачать <?=$row3->name?></h3>
            <input type="hidden" name="toaddpdf" value="<?=$iin1?>">
            <input type="hidden" name="refname" value="<?=$row3->id?>">
            <input type="submit" name="submit" class="form-group btn btn-outline-light " value="Загрузить">
        </form>
     <?php
                }
        }
    ?>
</div>
@endsection
