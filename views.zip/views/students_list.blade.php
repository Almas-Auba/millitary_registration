@extends('header')
@section('title')
    <title>Список студентов</title>
@endsection
@section('main_content')
    <div class="container ">
        <div >
            <form action="/filter" method="post"  class="d-flex m-3">
                @csrf
            <input type="text" class="form-control " value="" name="fname" placeholder="Введите Имя...">
            <input type="text" class="form-control ml-2" value="" name="fsurname" placeholder="Введите Фамилию...">
            <input type="text" class="form-control ml-2" value="" name="fedu" placeholder="Введите ИИН ...">
            <input type="submit" class="form-control ml-2" value="Фильтр" >
            </form>
        </div>
        <table class="table">
            <thead class="thead-light">
            <tr>
                <th scope="col">#</th>
                <th scope="col">Имя</th>
                <th scope="col">Отчество</th>
                <th scope="col">Фамилия</th>
                <th scope="col">Дата рождения</th>
                <th scope="col">ИИН</th>
                <th scope="col">Образование</th>
            </tr>
            </thead>
            <tbody><?php
            use Illuminate\Support\Facades\DB;
            $lists = DB::table('contacts')->get();
            foreach($lists as $stu){?>
            <tr>
                <th>{{$stu->id}}</th>
                <th>{{$stu->name}}</th>
                <th>{{$stu->lastname}}</th>
                <th>{{$stu->surname}}</th>
                <th>{{$stu->birthday}}</th>
                <th>{{$stu->inn}}</th>
                <th>{{$stu->education}}</th>
            </tr>
           <?php
            }
            ?>
            </tbody>
        </table>
    </div>

@endsection
