@extends('header_admin')
@section('admin_content')
        <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom" style="background: rgba(209,179,102,0.53);">
            <h1 class="h2">Воинский учет</h1>
            <div class="btn-toolbar mb-2 mb-md-0">
                <div class="btn-group mr-2">
                    <a href="/add_udo" class="btn btn-outline-light btn-primary">Добавить УДО</a>
                </div>
            </div>
        </div>
        <h2 style="background: rgba(209,179,102,0.53);">Таблица учета</h2>
        <div class="table-responsive" style="background: rgba(209,179,102,0.53);">
            <table class="table table-striped table-sm">
                <thead>
                <tr>
                    <th>Название</th>
                    <th>Адрес</th>
                    <th>Количество студентов находящичся в учете</th>
                </tr>
                </thead>
                <tbody>
                <?php
                use Illuminate\Support\Facades\DB;
                $udo = DB::table('udos')->get();
                foreach($udo as $row)
                {
                    ?>
                    <form action="/delete_udo" method="post">
                        @csrf
                        <tr>
                            <td><?=$row->name?></td>
                            <td><?=$row->address?></td>
                            <td class="text-center"><?=$row->quantity?></td>
                            <input type="hidden" name="idname" value="<?=$row->id?>">
                            <td><input type="submit" class="form-control btn-danger btn-outline-light" value="Удалить" name="delete"/></td>
                    </form>
                            <form action="/update_udo" method="post">
                                @csrf
                                <input type="hidden" name="idname" value="<?=$row->id?>">
                                <td><input type="submit" class="form-control btn-primary btn-outline-light" value="Изменить" name="edit"></td>
                            </form>
                <?php
                }
                ?>
                        </tr>
                </tbody>
            </table>
        </div

    @endsection
