@extends('header_admin')
@section('admin_content')
        <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom" style="background: rgba(209,179,102,0.53);">
            <h1 class="h2">Воинский учет</h1>
            <div class="btn-toolbar mb-2 mb-md-0">
                <div class="btn-group mr-2">
                    <a class="btn btn-sm btn-outline-secondary" href="add_spr.blade.php">Добавить</a>
                </div>
            </div>
        </div>
        <?php
            use Illuminate\Support\Facades\DB;
        if ( !empty($_POST['idname'])){
            $edit_udo = DB::table("udos")->get();
            foreach($edit_udo as $row)
            {
                if (($row->id)==$_POST['idname']){
                ?>
        <h2 style="background: rgba(209,179,102,0.53);">Измените данные</h2>
        <form action="/set_update" method="get">
            @csrf
            <div class="form-group mt-auto">
                <label >Название</label>
                <input type="text" class="form-control" name="nameof" value="<?=$row->name?>">
                <label >Адресс</label>
                <input type="text" class="form-control" name="addressnameofcom" value="<?=$row->address?>">
                <label >Количество студентов находящичся в учете</label>
                <input type="number" class="form-control" name="quantityofcom" value="<?=$row->quantity?>">
                <input type="hidden" name="idcommis" value="<?=$row->id?>">
                <button type="submit" class="btn btn-sm btn-outline-secondary mt-3" >Потвердить</button>
            </div>
        </form>
        <?php
                 }
            }
        }
        ?>
@endsection
